package org.example;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public class OTPService {

    private final Map<String, List<String>> otpStorage = new ConcurrentHashMap<>();

    // Methode zur Registrierung des Benutzers und zur Generierung der OTP-Liste
    public CompletableFuture<List<String>> registerUser(String username, String password, int iterations) {
        return CompletableFuture.supplyAsync(() -> {
            List<String> otpList = generateOtpList(password, iterations);
            otpStorage.put(username, otpList);
            return otpList;
        });
    }

    // Methode zur Validierung des OTPs
    public boolean validateOtp(String username, String otp) {
        List<String> otpList = otpStorage.get(username);
        if (otpList != null && otpList.contains(otp)) {
            otpList.remove(otp); // Verwendetes OTP entfernen
            return true;
        }
        return false;
    }

    // Methode zum Abrufen der OTP-Liste für einen Benutzer
    public List<String> getOtpListForUser(String username) {
        return otpStorage.getOrDefault(username, Collections.emptyList());
    }

    // Methode zur Generierung der OTPs basierend auf dem Passwort und der Anzahl der Iterationen
    private List<String> generateOtpList(String password, int iterations) {
        List<String> otpList = new ArrayList<>();
        String currentOtp = password;
        for (int i = 0; i < iterations; i++) {
            currentOtp = hash(currentOtp);
            otpList.add(currentOtp);
        }
        Collections.reverse(otpList); // Lamport OTPs rückwärts speichern
        return otpList;
    }

    // Eine einfache Hash-Funktion (SHA-256 für OTP-Generierung)
    private String hash(String input) {
        try {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            // Statt Base64.encodeToString() nutze eine hexadezimale Darstellung
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
