package org.example;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Controller
public class OTPController {

    private OTPService otpService = new OTPService();

    // GET-Mapping für die Registrierung
    @GetMapping("/register")
    public String showRegisterPage() {
        return "otp";  // Zeige das Formular für die Registrierung an
    }

    // GET-Mapping für das Login
    @GetMapping("/login")
    public String showLoginPage() {
        return "otp";  // Zeige das Formular für das Login an
    }

    // Registrierung des Benutzers
    @PostMapping("/register")
    public String registerUser(@RequestParam("username") String username,
                               @RequestParam("password") String password,
                               @RequestParam("iterations") int iterations,
                               Model model) {

        List<String> otpList = otpService.registerUser(username, password, iterations).join();

        // Speichern der OTP-Liste im Model, damit sie heruntergeladen werden kann
        model.addAttribute("username", username);

        return "otp";  // gleiche HTML-Datei verwenden
    }

    // Login des Benutzers mit OTP
    @PostMapping("/login")
    public String loginUser(@RequestParam("username") String username,
                            @RequestParam("otp") String otp,
                            Model model) {

        boolean isValid = otpService.validateOtp(username, otp);
        if (isValid) {
            model.addAttribute("message", "Login erfolgreich");
        } else {
            model.addAttribute("message", "Ungültiges OTP oder OTP wurde bereits verwendet");
        }

        return "otp";  // gleiche HTML-Datei verwenden
    }

    // Methode für den Download der OTPs
    @GetMapping("/download")
    public ResponseEntity<InputStreamResource> downloadOtps(@RequestParam("username") String username) throws IOException {
        List<String> otpList = otpService.getOtpListForUser(username);

        // Erstellen des Inhalts der .txt-Datei
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        for (String otp : otpList) {
            outputStream.write((otp + "\n").getBytes(StandardCharsets.UTF_8));
        }

        // Rückgabe der Datei als Download
        ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
        String filename = "OTPs_" + username + ".txt";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + filename)
                .contentType(MediaType.TEXT_PLAIN)
                .body(new InputStreamResource(inputStream));
    }
}
